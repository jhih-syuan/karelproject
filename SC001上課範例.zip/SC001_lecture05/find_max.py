"""
File: find_max.py
Name:
--------------------------
This program finds the maximum value
among all user inputs.

This file can be used as a reference
when working on Problem 4 in
Assignment 2.
"""

# This constant controls when to stop
EXIT = -1


def main():
    """
    This program finds the maximum among
    user inputs
    """
    pass


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
    main()
