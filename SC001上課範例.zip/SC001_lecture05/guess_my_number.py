"""
File: guess_my_number.py
Name:
-----------------------------
This program runs a console game
called "Guess My Number".

The program repeatedly asks the user
to guess a number until the correct
answer is given.
"""

# This number controls when to stop the game
SECRET = 32


def main():
    pass


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
    main()
