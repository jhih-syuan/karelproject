"""
File: function.py
Name:
-------------------------------
This program demonstrates essential
function concepts by using the
my_add and my_subtract functions.
"""


def main():
	pass


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
	main()
