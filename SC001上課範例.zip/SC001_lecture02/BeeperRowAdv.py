"""
File: BeeperRowAdv.py
Name:
------------------------------
This program guides Karel to place beepers
along Street 1, even if some beepers are
already present.

The goal is to make sure every corner on
Street 1 has exactly one beeper. The
solution should work for different world
sizes, not just one specific world.
"""

from karel.stanfordkarel import *


def main():
    """
    Karel will fill the first Street in any world
    """
    pass












####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)