"""
File: replace_keyword.py
Name:
----------------------
This program demonstrates how to
replace an old word with a new word
in a given string by using the
replace() function.
"""


def main():
	pass


def replace(old_s, old_word, new_word):
	pass


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
	main()
